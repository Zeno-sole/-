
The tools have not been  bundled  because  of  license  restrictions.   I  can
recommend the following tools to test the modbus implementation:

 - Modpoll Modbus� Polling Tool: A free command line based Modbus
   master simulator and test utility.

   available: http://www.focus-sw.com/fieldtalk/modpoll.html

 - Modbus Poll master simulator: A Modbus master simulator with a 
   excellent user interface. Support RTU and ASCII modes.

   available: http://www.modbustools.com/modbus_poll.asp

Simple  download  the  Modpoll  Polling  Tool  and  place  it  with  the  name
'modpoll.exe' in this directory. 


